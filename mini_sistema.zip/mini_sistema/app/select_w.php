<?php require_once __DIR__ . '/../includes/functions.php';
require_once __DIR__ . '/../login/verifica_user.php';
 ?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="../style/style.css">
    <title>Consulta Aluno</title>
</head>

<body>
    <?php include '../includes/header.php'; ?>
    <h3>Consulta de Aluno</h3>
    <form action="" method="post">
        <label for="id">Aluno ID: </label>
        <input type="number" name="id" id="id">
        <input type="submit" value="Consultar">
    </form>
    <?php
    if ($_SERVER['REQUEST_METHOD'] == "POST") {
        consultar($conexao, $_POST['id']);
    }
    include '../includes/header.php';
    ?>
</body>

</html>